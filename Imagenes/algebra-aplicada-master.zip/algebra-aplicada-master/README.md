# Curso de Algebra Lineal Aplicada a Machine Learning con Python

## Profesor: Sebastian Sosa
## Version: 09/2019

## Basado en el Segundo Capitulo "2 Algebra Lineal" del libro http://www.deeplearningbook.org/

@book{Goodfellow-et-al-2016,
    title={Deep Learning},
    author={Ian Goodfellow and Yoshua Bengio and Aaron Courville},
    publisher={MIT Press},
    note={\url{http://www.deeplearningbook.org}},
    year={2016}
}

## Imagenes descargadas desde

https://www.cl.cam.ac.uk/research/dtg/attarchive/facedatabase.html

40 sujetos distintos, diez imagenes / tomas del rostro de cada uno. Las imagenes tienen diferente iluminacion, expresiones faciales, etc...
